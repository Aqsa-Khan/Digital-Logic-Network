
/**
 * Write a description of class Gate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Gate
{
    Node outputNode; 
    String name;
    public Gate(String n, Node n1){
        name=n;
        outputNode = n1;
    }
    
    abstract byte getOutput();
}
