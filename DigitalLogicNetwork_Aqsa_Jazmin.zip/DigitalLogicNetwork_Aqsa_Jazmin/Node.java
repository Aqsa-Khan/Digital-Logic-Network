
/**
 * Write a description of class Node here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Node
{
    
    String name;
    byte digitalVal;
    
    public Node(String n, byte dVal){
        name = n; 
        digitalVal = dVal;
    }
    
    abstract byte getVal();
}
