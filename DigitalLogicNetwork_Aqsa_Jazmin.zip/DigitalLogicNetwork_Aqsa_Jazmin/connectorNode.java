
/**
 * Write a description of class connectorNode here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class connectorNode extends Node
{
   Gate forward;
   Gate backward;
   
   public connectorNode(String name, byte digitalVal, Gate forward, Gate backward){
       super(name, digitalVal);
       this.forward = forward;
       this.backward = backward;
    }
    
   public byte getVal(){
       digitalVal = backward.getOutput();
       return digitalVal;
    }
}
