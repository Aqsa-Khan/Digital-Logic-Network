
/**
 * Write a description of class ORgate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ORgate extends Gate
{
   Node input1;
   Node input2;
   public ORgate(String name, Node outputNode, Node n1, Node n2){
       super(name,outputNode);
       input1 = n1;
       input2 = n2;
   }
   
   public byte getOutput(){
       byte inputone = input1.getVal();
       byte inputtwo = input2.getVal();
       if(inputone == 1 || inputtwo == 1){
           return 1;
        }else{
            return 0;
        }
    }
}
