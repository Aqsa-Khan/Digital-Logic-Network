
/**
 * Write a description of class inputNode here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class inputNode extends Node{
    //how do u make a variable with a gate, what
    //how do u initialize said gate variable in inputNode
    
    
    Gate connectorG;
    
    public inputNode(String name, byte digitalVal, Gate connectorG){
        super(name, digitalVal);
    }
    
    public byte getVal(){
        return digitalVal;
    }
}
