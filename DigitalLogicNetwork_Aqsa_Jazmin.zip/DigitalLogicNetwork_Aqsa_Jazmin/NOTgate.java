
/**
 * Write a description of class NOTgate here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class NOTgate extends Gate
{
   Node input1;
   public NOTgate(String name, Node outputNode, Node n1){
       super(name, outputNode);
       input1 = n1;
   }
   
   public byte getOutput(){
       byte inputone = input1.getVal();
       if(inputone == 1){
           return 0;
        }else{
            return 1;
        }
    }
}
