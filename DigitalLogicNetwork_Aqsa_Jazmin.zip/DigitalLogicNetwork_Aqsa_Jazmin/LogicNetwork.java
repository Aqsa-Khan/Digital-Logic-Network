
/**
 * Write a description of class LogicNetwork here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.HashMap;
public class LogicNetwork
{
    HashMap <String, Gate> Gates= new HashMap <String,Gate> ();
    
    
    public void readFile(String inFile){
        In reader = new In(inFile);
        while(reader.hasNextLine()){
            String s = reader.readLine();
            String[] ss = s.split(" ");
            if(s.charAt(0) == 'g'){
                Gate g = null;
                if(ss[1].equals("AND")){
                     g = new ANDgate(ss[0]);
                }else if(ss[1].equals("OR")){
                    g = newORgate(ss[0]);
                }else if(ss[1].equals("NOT")){
                    g = new NOTgate(ss[0]);
                }
                gates.put(ss[0], g);
            }
        }
    }
}
